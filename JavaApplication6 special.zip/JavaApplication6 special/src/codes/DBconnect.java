/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codes;

import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
/**
 *
 * @author poornima
 */
public class DBconnect {    
    public static Connection connect(){
        
        Connection conn = null;
        
 try {
      Class.forName("com.mysql.jdbc.Driver");
      conn =(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/project123","root","");
             
 }  catch (Exception e){    
     JOptionPane.showMessageDialog(null,e);
     
 }
       
        
        return conn;
    }
    
}
